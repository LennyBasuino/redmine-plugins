module QPP_Constants

  PLUGIN_NAME = :redmine_default_columns

  QUERY_TEMP_NAME = "_QPP_"
  QUERY_DEFAULT_GLOBAL_NAME = "Global_Default"
  QUERY_DEFAULT_PFX = "Default_"
  PROJECT_DEFAULT_SUFFIX = "Project"
  TYPE_CUSTOM_FIELD_NAME = "Type"
  QUERY_DEFAULT_NAME = "Default"
  MY_QUERY_DEFAULT_NAME = "MyDefault"
  MY_QUERY_GLOBAL_DEFAULT_NAME = "MyGlobal"
  MY_QUERY_HOME_NAME = "MyHome"
  MY_QUERY_HOME_NAME_DEFAULT = "My issues..."

  def self.settings
    Setting["plugin_#{PLUGIN_NAME.to_s}"]
  end

end
